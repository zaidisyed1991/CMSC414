#similar behavior to grading.sh, but only runs task2 tests,
# and only runs for one submission.
# example usage: ./regrade2.sh ./submissions/<student>
# script will echo test result summary
# full details are output to ./submissions/<student>/task2log

shopt -s extglob

#expects input files in directory 'inputs',
#   and submissions in directory 'submissions'

BASEDIR=$PWD
INPUTS=$BASEDIR/inputs


grades=$BASEDIR/outputs/p3grades.csv


#task1 inputs
pubkey1=$INPUTS/pubkey1.pem
privkey1=$INPUTS/privkey1.pem
pubkey2=$INPUTS/pubkey2.pem
privkey2=$INPUTS/privkey2.pem

ptext_short=$INPUTS/ptext_short
ptext_long=$INPUTS/ptext_long
ptext_rand=$INPUTS/ptext_rand

bad=$INPUTS/bad

#task2 inputs
salt1=$INPUTS/salt1.txt
salt2=$INPUTS/salt2.txt
salt3=$INPUTS/salt3.txt
salt4=$INPUTS/salt4.txt
msg1=$INPUTS/msg1.txt
msg2=$INPUTS/msg2.txt
msg3=$INPUTS/msg3.txt
msg4=$INPUTS/msg4.txt
key1=$INPUTS/key_sha1_0_salt1_msg1
key1b=$INPUTS/key1b
key2=$INPUTS/key_sha1_5_salt1_msg1
key3=$INPUTS/key_sha1_5_salt2_msg2
key4=$INPUTS/key_sha256_3_salt3_msg3
key5=$INPUTS/key_sha256_3_salt4_msg4
key6=$INPUTS/key_sha256_20_salt1_msg1

function task2setup {

        ./multihash sha1 0 $salt1 $msg1 > output1

        ./multihash sha1 5 $salt1 $msg1 > output2

        ./multihash sha1 5 $salt2 $msg2 > output3

        ./multihash sha256 3 $salt3 $msg3 > output4

        ./multihash sha256 3 $salt4 $msg4 > output5

        ./multihash sha256 20 $salt1 $msg1 > output6

}

function task2diff {

    diff $key1 output1 > diff1
    res1=$?

    diff $key1b output1 > diff1b
    res1b=$?

    diff $key2 output2 > diff2
    res2=$?

    diff $key3 output3 > diff3
    res3=$?

    diff $key4 output4 > diff4
    res4=$?

    diff $key5 output5 > diff5
    res5=$?

    diff $key6 output6 > diff6
    res6=$?

    if [[ $res1 -eq 0 ]] || [[ $res1b -eq 0 ]]; then
        echo "diff test 1: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff1
        if [[ $check == "1c1" ]]; then
            echo "diff test 1: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 1: FAILED"
        fi
    fi

    if [ $res2 -eq 0 ]; then
        echo "diff test 2: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff2
        if [[ $check == "1c1" ]]; then
            echo "diff test 2: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 2: FAILED"
        fi
    fi

    if [ $res3 -eq 0 ]; then
        echo "diff test 3: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff3
        if [[ $check == "1c1" ]]; then
            echo "diff test 3: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 3: FAILED"
        fi
    fi

    if [ $res4 -eq 0 ]; then
        echo "diff test 4: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff4
        if [[ $check == "1c1" ]]; then
            echo "diff test 4: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 4: FAILED"
        fi
    fi

    if [ $res5 -eq 0 ]; then
        echo "diff test 5: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff5
        if [[ $check == "1c1" ]]; then
            echo "diff test 5: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 5: FAILED"
        fi
    fi

    if [ $res6 -eq 0 ]; then
        echo "diff test 6: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff6
        if [[ $check == "1c1" ]]; then
            echo "diff test 6: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 6: FAILED"
        fi
    fi
}

function task2error {
    #not a real hash function
    ./multihash banana 5 $salt1 $msg1 &>/dev/null
    res1=$?

    #not a number
    ./multihash sha1 x $salt1 $msg1 &>/dev/null
    res2=$?

    #too many arguments
    ./multihash sha256 5 $salt1 $msg1 $msg1 &>/dev/null
    res3=$?

    #not enough arguments
    ./multihash sha256 5 $salt1 &>/dev/null
    res4=$?

    if [ $res1 -eq 1 ]; then
        echo "error test 1: PASSED"
        ((task2_score += 1))
    else
        echo "error test 1: FAILED"
    fi

    if [ $res2 -eq 1 ]; then
        echo "error test 2: PASSED"
        ((task2_score += 1))
    else
        echo "error test 2: FAILED"
    fi

    if [ $res3 -eq 1 ]; then
        echo "error test 3: PASSED"
        ((task2_score += 1))
    else
        echo "error test 3: FAILED"
    fi

    if [ $res4 -eq 1 ]; then
        echo "error test 4: PASSED"
        ((task2_score += 1))
    else
        echo "error test 4: FAILED"
    fi

}

function task2grade {
    echo "task2: "
    #check for multihash.c
    if ! [[ -f "multihash.c" ]]; then
        echo "no multihash.c file found"
        let task2_score=-1
    else
        #check for makefile
        if ! [[ -f "Makefile" ]]; then
            cp $INPUTS/Makefile .
        fi

        if ! [[ -f "multihash" ]]; then
            echo "no multihash executable found :("
            let task2_score=-1
        #otherwise:
        else
            task2setup
            task2diff
            task2error
        fi
    fi
}

function grade {
    cd $dir

    if [[ -d "task2" ]]; then
        cd task2
        task2grade
        cd ..
    else
        echo "no task2 directory found"
        let task2_score=-1
    fi

}



dir=$1
student=$(basename $dir)
echo "*********** grading: ""$student" "***********"
let task2_score=0
grade &> $dir/task2log
echo "task2 score: $task2_score"

