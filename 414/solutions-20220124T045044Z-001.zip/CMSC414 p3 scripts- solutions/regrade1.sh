#similar behavior to grading.sh, but only runs task1 tests,
# and only runs for one submission.
# example usage: ./regrade1.sh ./submissions/<student>
# 

shopt -s extglob

#expects input files in directory 'inputs',
#   and submissions in directory 'submissions'

BASEDIR=$PWD
INPUTS=$BASEDIR/inputs


grades=$BASEDIR/outputs/p3grades.csv


#task1 inputs
pubkey1=$INPUTS/pubkey1.pem
privkey1=$INPUTS/privkey1.pem
pubkey2=$INPUTS/pubkey2.pem
privkey2=$INPUTS/privkey2.pem

ptext_short=$INPUTS/ptext_short
ptext_long=$INPUTS/ptext_long
ptext_rand=$INPUTS/ptext_rand

bad=$INPUTS/bad

#task2 inputs
salt1=$INPUTS/salt1.txt
salt2=$INPUTS/salt2.txt
salt3=$INPUTS/salt3.txt
salt4=$INPUTS/salt4.txt
msg1=$INPUTS/msg1.txt
msg2=$INPUTS/msg2.txt
msg3=$INPUTS/msg3.txt
msg4=$INPUTS/msg4.txt
key1=$INPUTS/key_sha1_0_salt1_msg1
key1b=$INPUTS/key1b
key2=$INPUTS/key_sha1_5_salt1_msg1
key3=$INPUTS/key_sha1_5_salt2_msg2
key4=$INPUTS/key_sha256_3_salt3_msg3
key5=$INPUTS/key_sha256_3_salt4_msg4
key6=$INPUTS/key_sha256_20_salt1_msg1

#generates the following files in each directory:
# ctext_* for each encryption
# output_* for each decryption
# diff_* for each diff of expected output/actual output
# output1, output2, etc for each hash
# diff1, diff2, etc for each diff of expected output/actual output
# log containing stdout/stderr while running

function task1setup {
    #normal encrypt 1e
    ./hybridEncrypt e $pubkey1 $ptext_short > ctext_short
    res1e=$?
    #echo $res1e
    #normal decrypt 1d
    ./hybridEncrypt d $privkey1 ctext_short > output_short
    res1d=$?
    #echo $res2d

    #normal encrypt 2
    ./hybridEncrypt e $pubkey1 $ptext_long > ctext_long
    res2e=$?
    #echo $res2e

    #normal decrypt 2
    ./hybridEncrypt d $privkey1 ctext_long > output_long
    res2d=$?
    #echo $res2d

    #normal encrypt 3
    ./hybridEncrypt e $pubkey2 $ptext_rand > ctext_rand
    res3e=$?
    #echo $res3e
    #normal decrypt 3
    ./hybridEncrypt d $privkey2 ctext_rand > output_rand
    res3d=$?
    #echo $res3d


    if [ $res1e -eq 0 ]; then
        echo "setup test 1e: PASSED"
        ((task1_score+=1))
    else
        echo "setup test 1e: FAILED (result: $res1e)"

    fi

    if [ $res1d -eq 0 ]; then
        echo "setup test 1d: PASSED"
        ((task1_score+=1))
    else
        echo "setup test 1d: FAILED (result: $res1d)"
    fi


    if [ $res2e -eq 0 ]; then
        echo "setup test 2e: PASSED"
        ((task1_score+=1))
    else
        echo "setup test 2e: FAILED (result: $res2e)"
    fi


    if [ $res2d -eq 0 ]; then
        echo "setup test 2d: PASSED"
        ((task1_score+=1))
    else
        echo "setup test 2d: FAILED (result: $res2d)"
    fi

    if [ $res3e -eq 0 ]; then
        echo "setup test 3e: PASSED"
        ((task1_score+=1))
    else
        echo "setup test 3e: FAILED (result: $res3e)"

    fi

    if [ $res3d -eq 0 ]; then
        echo "setup test 3d: PASSED"
        ((task1_score+=1))
    else
        echo "setup test 3d: FAILED (result: $res3d)"
    fi

}

function task1diff {
    diff $ptext_short ./output_short > diff_short
    res1=$?

    diff $ptext_long ./output_long > diff_long
    res2=$?

    diff $ptext_rand ./output_rand > diff_rand
    res3=$?

    if [ $res1 -eq 0 ]; then
        echo "diff test 1: PASSED"
        ((task1_score+=1))
    else
        echo "diff test 1: FAILED"
    fi

    if [ $res2 -eq 0 ]; then
        echo "diff test 2: PASSED"
        ((task1_score+=1))
    else
        echo "diff test 2: FAILED"
    fi

    if [ $res3 -eq 0 ]; then
        echo "diff test 3: PASSED"
        ((task1_score+=1))
    else
        echo "diff test 3: FAILED"
    fi

}

function task1auth {
    #echo "badbadbadbadbad" > ./bad

    cat ./ctext_short $bad > ./bad_short
    ./hybridEncrypt d $privkey1 ./bad_short #>/dev/null 2>&1
    res1=$?
    #echo "res1: $res1"

    cat $bad ./ctext_rand > ./bad_rand
    ./hybridEncrypt d $privkey2 ./bad_rand #>/dev/null 2>&1
    res2=$?
    #echo "res2: $res2"


    if [ $res1 -eq 1 ] || [ $res1 -eq 2 ]; then
      echo "auth test 1: PASSED"
      ((task1_score+=1))
    else
      echo "auth test 1: FAILED"
    fi

    if [ $res2 -eq 1 ] || [ $res2 -eq 2 ]; then
      echo "auth test 2: PASSED"
      ((task1_score+=1))
    else
      echo "auth test 2: FAILED"
    fi

}

function task1error {
    # not a real key file
    echo "hi" > fake_key
    ./hybridEncrypt e fake_key $ptext_short
    res1=$?

    #keyfile does not exist
    ./hybridEncrypt e invisiblekey $ptext_short
    res2=$?

    #ptext does not exist
    ./hybridEncrypt e $pubkey1 invisibleptext
    res3=$?

    #ctext does not exist
    ./hybridEncrypt d $privkey invisiblectext
    res4=$?

    # not a valid option
    ./hybridEncrypt x $pubkey1 $ptext_short
    res5=$?

    # decrypting with wrong key
    ./hybridEncrypt e $pubkey1 $ptext_short > fake_ctext
    ./hybridEncrypt d privkey2.pem fake_ctext
    res6=$?

    # not enough arguments
    ./hybridEncrypt e
    res7=$?

    if [ $res1 -eq 1 ] || [ $res1 -eq 2 ]; then
        echo "error test 1: PASSED"
        ((task1_score+=1))
    else
        echo "error test 1: FAILED"
    fi

    if [ $res2 -eq 1 ] || [ $res2 -eq 2 ]; then
        echo "error test 2: PASSED"
        ((task1_score+=1))
    else
        echo "error test 2: FAILED"
    fi

    if [ $res3 -eq 1 ] || [ $res3 -eq 2 ]; then
        echo "error test 3: PASSED"
        ((task1_score+=1))
    else
        echo "error test 3: FAILED"
    fi

    if [ $res4 -eq 1 ] || [ $res4 -eq 2 ]; then
        echo "error test 4: PASSED"
        ((task1_score+=1))
    else
        echo "error test 4: FAILED"
    fi

    if [ $res5 -eq 1 ] || [ $res5 -eq 2 ]; then
        echo "error test 5: PASSED"
        ((task1_score+=1))
    else
        echo "error test 5: FAILED"
    fi

    if [ $res6 -eq 1 ] || [ $res6 -eq 2 ]; then
        echo "error test 6: PASSED"
        ((task1_score+=1))
    else
        echo "error test 6: FAILED"
    fi

    if [ $res7 -eq 1 ] || [ $res7 -eq 2 ]; then
        echo "error test 7: PASSED"
        ((task1_score+=1))
    else
        echo "error test 7: FAILED"
    fi

}

function task1grade {
    echo "task1: "
    #check for multihash.c
    if ! [[ -f "hybridEncrypt.c" ]]; then
        echo "no hybridEncrypt.c file found"
        let task1_score=-1
    else
        #check for makefile
        if ! [[ -f "Makefile" ]]; then
            cp $INPUTS/Makefile .
        fi

        make

        #if make failed, done
        if ! [[ -f "hybridEncrypt" ]]; then
            echo "no hybridEncrypt executable found :("
            let task1_score=-1
        #otherwise:
        else
            task1setup
            task1diff
            task1auth
            task1error
        fi
    fi
}

function task2setup {

        ./multihash sha1 0 $salt1 $msg1 > output1

        ./multihash sha1 5 $salt1 $msg1 > output2

        ./multihash sha1 5 $salt2 $msg2 > output3

        ./multihash sha256 3 $salt3 $msg3 > output4

        ./multihash sha256 3 $salt4 $msg4 > output5

        ./multihash sha256 20 $salt1 $msg1 > output6

}

function task2diff {

    diff $key1 output1 > diff1
    res1=$?

    diff $key1b output1 > diff1b
    res1b=$?

    diff $key2 output2 > diff2
    res2=$?

    diff $key3 output3 > diff3
    res3=$?

    diff $key4 output4 > diff4
    res4=$?

    diff $key5 output5 > diff5
    res5=$?

    diff $key6 output6 > diff6
    res6=$?

    if [[ $res1 -eq 0 ]] || [[ $res1b -eq 0 ]]; then
        echo "diff test 1: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff1
        if [[ check == "1c1" ]]; then
            echo "diff test 1: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 1: FAILED"
        fi
    fi

    if [ $res2 -eq 0 ]; then
        echo "diff test 2: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff2
        if [[ check == "1c1" ]]; then
            echo "diff test 2: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 2: FAILED"
        fi
    fi

    if [ $res3 -eq 0 ]; then
        echo "diff test 3: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff3
        if [[ check == "1c1" ]]; then
            echo "diff test 3: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 3: FAILED"
        fi
    fi

    if [ $res4 -eq 0 ]; then
        echo "diff test 4: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff4
        if [[ check == "1c1" ]]; then
            echo "diff test 4: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 4: FAILED"
        fi
    fi

    if [ $res5 -eq 0 ]; then
        echo "diff test 5: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff5
        if [[ check == "1c1" ]]; then
            echo "diff test 5: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 5: FAILED"
        fi
    fi

    if [ $res6 -eq 0 ]; then
        echo "diff test 6: PASSED"
        ((task2_score += 1))
    else
        read -r check<diff6
        if [[ check == "1c1" ]]; then
            echo "diff test 6: PASSED"
            ((task2_score += 1))
        else
            echo "diff test 6: FAILED"
        fi
    fi
}

function task2error {
    #not a real hash function
    ./multihash banana 5 $salt1 $msg1 &>/dev/null
    res1=$?

    #not a number
    ./multihash sha1 x $salt1 $msg1 &>/dev/null
    res2=$?

    #too many arguments
    ./multihash sha256 5 $salt1 $msg1 $msg1 &>/dev/null
    res3=$?

    #not enough arguments
    ./multihash sha256 5 $salt1 &>/dev/null
    res4=$?

    if [ $res1 -eq 1 ]; then
        echo "error test 1: PASSED"
        ((task2_score += 1))
    else
        echo "error test 1: FAILED"
    fi

    if [ $res2 -eq 1 ]; then
        echo "error test 2: PASSED"
        ((task2_score += 1))
    else
        echo "error test 2: FAILED"
    fi

    if [ $res3 -eq 1 ]; then
        echo "error test 3: PASSED"
        ((task2_score += 1))
    else
        echo "error test 3: FAILED"
    fi

    if [ $res4 -eq 1 ]; then
        echo "error test 4: PASSED"
        ((task2_score += 1))
    else
        echo "error test 4: FAILED"
    fi

}

function task2grade {
    echo "task2: "
    #check for multihash.c
    if ! [[ -f "multihash.c" ]]; then
        echo "no multihash.c file found"
        let task2_score=-1
    else
        #check for makefile
        if ! [[ -f "Makefile" ]]; then
            cp $INPUTS/Makefile .
        fi

        make

        #if make failed, done
        if ! [[ -f "multihash" ]]; then
            echo "no multihash executable found :("
            let task2_score=-1
        #otherwise:
        else
            task2setup
            task2diff
            task2error
        fi
    fi
}

function grade {
    cd $dir

    if [[ -d "task1" ]]; then
        cd task1
        task1grade
        cd ..
    else
        echo "no task1 directory found"
        let task1_score=-1
    fi

    if [[ -d "task2" ]]; then
        cd task2
        task2grade
        cd ..
    else
        echo "no task2 directory found"
        let task2_score=-1
    fi

}


dir=$1
student=$(basename $dir)
echo "*********** grading: ""$student" "***********"
let task1_score=0
grade &> $dir/task1log
echo "task1 score: $task1_score"


